gradle clean build -PbuildInfo.build.number=123
