package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.constraints.NotBlank;

/**
 * The Interface DateValidator.
 */
@NotBlank(message = "BETTFUNC1004")
@Documented
@Constraint(validatedBy = DateConstraint.class)
@Target( {ElementType.FIELD,ElementType.PARAMETER} )
@Retention(RetentionPolicy.RUNTIME)
public @interface DateValidator {
String message() default "BETTFUNC1002";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

}
