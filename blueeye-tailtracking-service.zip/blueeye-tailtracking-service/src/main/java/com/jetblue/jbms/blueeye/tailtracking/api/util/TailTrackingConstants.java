package com.jetblue.jbms.blueeye.tailtracking.api.util;

/**
 * @author RJain
 * 
 * Enum class for defining constants.
 * 
 */

public enum TailTrackingConstants {


	DATE_FORMAT("yyyy-MM-dd"),
	TIME("T06:00:00-04:00"),
	DATE_TIME_FORMAT("yyyy-MM-dd'T'HH:mm:ssXXX"),
	CARRIER_CODE("B6"),
	TRUE("true"),
	FALSE("false"),
	AFT_CANCELLED("Cancel"),
	AFT_DVC_DIVERTED("DVC"),
	AFT_DVH_DIVERTED("DVH"),
	SUBTEXT_CANCELLED("Cancelled"),
	SUBTEXT_INFLIGHT("In Flight"),
	SUBTEXT_LANDED("Landed"),
	SUBTEXT_ARRIVED("Arrived"),
	SUBTEXT_DIVERTED("Diverted to "),
	SUBTEXT_ORIGIN("New Origin:"),
	SUBTEXT_PREVTAIL("Previous Tail: "),
	SFLRQKEY("SFLRequestKey "),
	SFLRSKEY("SFLResponseKey :"),
	TRANSACTION_ID("transaction_id"),
	FLIGHT_NUMBER("flightnumber"),
	SCH_DEP_DATE("schdepdate"),
	DEP_STN("depstn"),
	ARR_STN("arrstn"),
	TAIL_NUMBER("tailnumber");
	
	private String value;

	TailTrackingConstants(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
