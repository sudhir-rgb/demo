package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.StringUtils;

public class FlightNumberConstraint implements ConstraintValidator<FlightNumberValidator, String> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FlightNumberConstraint.class);
	
	private String numberErrorMessage;
	private String lengthErrorMessage;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
	public void initialize(final FlightNumberValidator constraintAnnotation) {
		numberErrorMessage = constraintAnnotation.numberErrorMessage();
		lengthErrorMessage = constraintAnnotation.lengthErrorMessage();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
	public boolean isValid(String flighNumber, ConstraintValidatorContext context) {

		String regex = "[0-9]+";
		String regexLength = "^[0-9]{1,4}$";

		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(flighNumber);
		Pattern patternLength = Pattern.compile(regexLength);
		Matcher matcherLength = patternLength.matcher(flighNumber);

		if (StringUtils.isBlank(flighNumber)) {
			return false;
		} else if (!matcher.matches()) {
			LOGGER.error(String.format("FLight number pattern matching error flightnum: %s pattern: %s", flighNumber, regex)).log();
			context.buildConstraintViolationWithTemplate(numberErrorMessage).addConstraintViolation()
					.disableDefaultConstraintViolation();
			return false;
		} else if (!matcherLength.matches()) {
			LOGGER.error(String.format("FLight number pattern matching error flightnum: %s pattern: %s", flighNumber, regex)).log();
			context.buildConstraintViolationWithTemplate(lengthErrorMessage).addConstraintViolation()
					.disableDefaultConstraintViolation();
			return false;
		}
		return true;
	}

}