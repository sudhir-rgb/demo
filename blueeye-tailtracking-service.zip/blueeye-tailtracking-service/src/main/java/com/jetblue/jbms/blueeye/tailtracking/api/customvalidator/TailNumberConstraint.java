package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.StringUtils;

public class TailNumberConstraint implements ConstraintValidator<TailNumberValidator, String> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TailNumberConstraint.class);
	
	private String numberErrorMessage;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
	public void initialize(final TailNumberValidator constraintAnnotation) {
		numberErrorMessage = constraintAnnotation.numberErrorMessage();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
	public boolean isValid(String tailnumber, ConstraintValidatorContext context) {

		String regex = "[0-9]+";

		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(tailnumber);

		if (StringUtils.isBlank(tailnumber)) {
			return false;
		} else if (!matcher.matches()) {
			LOGGER.error(String.format("Tailnumber pattern matching error tailnum: %s pattern: %s", tailnumber, regex)).log();
			context.buildConstraintViolationWithTemplate(numberErrorMessage).addConstraintViolation()
					.disableDefaultConstraintViolation();
			return false;
		}
		return true;
	}

}