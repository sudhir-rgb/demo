package com.jetblue.jbms.blueeye.tailtracking.api.service;

import static com.jetblue.jbms.common.log.Utils.unwrap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingDetailsResponse;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingRequest;
import com.jetblue.jbms.blueeye.tailtracking.api.transform.TailTrackingTransform;
import com.jetblue.jbms.blueeye.tailtracking.api.util.JbDateTimeUtil;
import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingConstants;
import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingErrorCodes;
import com.jetblue.jbms.common.exception.JbException;
import com.jetblue.jbms.common.flight.model.ScheduledFlightLeg;
import com.jetblue.jbms.common.flight.model.TailTrackingDetail;
import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosNoDataFoundException;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosTechnicalException;
import com.jetblue.jbms.cosmos.common.ref.model.AcftTailDesignTypeDocument;
import com.jetblue.jbms.cosmos.common.ref.model.Aircraft;

/**
 * The Class for Service Implementation
 * 
 * @author RJain & RKukadeja
 *
 */

@Service
public class TailTrackingService {

	@Autowired
	private FlightDomainService flightDomainService;

	@Autowired
	private ReferenceDomainService refDomainService;

	private static final Logger LOGGER = LoggerFactory.getLogger(TailTrackingService.class);

	/*
	 * Method to get tailTracking details
	 * 
	 * @param airlinecode
	 * 
	 * @param flightnumber
	 * 
	 * @param schdepdate
	 * 
	 * @param depstn
	 * 
	 * @param arrstn
	 * 
	 * @param tailnumber
	 * 
	 * @throws JbException
	 * 
	 * @return TailTrackingDetailsResponse
	 */

	public TailTrackingDetailsResponse getTailTrackingDetails(String airlinecode, String flightnumber,
			String schdepdate, String depstn, String arrstn, String tailnumber) throws JbException {
		try {
			TailTrackingRequest tailTrackingRQ = getTailTrackingRequest(airlinecode, flightnumber, schdepdate, depstn,
					arrstn, tailnumber);
			List<TailTrackingDetail> tailTrackingCosmosResponse = getTailTrackingCosmosResponse(tailTrackingRQ);
			return TailTrackingTransform.transformTailTrackingResponse(tailTrackingCosmosResponse,
					validateFlightNumberBusinessCheck(tailTrackingCosmosResponse, tailTrackingRQ), tailTrackingRQ,
					getAcftByTailNumber(tailnumber), getTailDesignDetails());
		} catch (JbException e) {
			throw e;
		} catch (Exception e) {
			throw new JbException(HttpStatus.INTERNAL_SERVER_ERROR, TailTrackingErrorCodes.BETTFUNC1005.getCode(),
					MDC.get(TailTrackingConstants.TRANSACTION_ID.toString()));
		}
	}

	/*
	 * Method to get Aircraft using tailNumber
	 * 
	 * @param tailNumber
	 * 
	 * @return Aircraft
	 */
	private Aircraft getAcftByTailNumber(String tailNumber) {
		Aircraft aircraft = null;
		try {
			Map<String, List<Aircraft>> aircraftByTailNumberCollection = refDomainService.getAllAircrafts();
			aircraft = aircraftByTailNumberCollection.get(tailNumber).get(0);
		} catch (RefCosmosNoDataFoundException refCosmosNoDataEx) {
			LOGGER.error(String.format("No Aircraft data found in ref cosmos for tailnumber: %s %s", tailNumber,
					ExceptionUtils.getStackTrace(unwrap(refCosmosNoDataEx)))).log();

		} catch (RefCosmosTechnicalException refCosmosTechEx) {
			LOGGER.error(String.format(
					"Technical exception occured in ref cosmos while fetching aircraft info for tailnumber: %s %s",
					tailNumber, ExceptionUtils.getStackTrace(unwrap(refCosmosTechEx)))).log();
		}
		return aircraft;
	}

	/*
	 * Method to get tail design details list from ref domain
	 */
	public Map<String,List<AcftTailDesignTypeDocument>> getTailDesignDetails() {
		Map<String,List<AcftTailDesignTypeDocument>> tailDesignDetailsList = null;
		try {
			tailDesignDetailsList = refDomainService.getTailDesignDetails();
		} catch (RefCosmosTechnicalException refTechEx) {
			LOGGER.error(String.format("Exception occured while getting tail design details list %s",
					ExceptionUtils.getStackTrace(unwrap(refTechEx)))).log();
		}
		return tailDesignDetailsList;
	}

	/*
	 * Method to get tailTrackingRequest from input parameters
	 * 
	 * @return tailTrackingRequest
	 */
	private TailTrackingRequest getTailTrackingRequest(String airlinecode, String flightnumber, String schdepdate,
			String depstn, String arrstn, String tailnumber) {
		return TailTrackingTransform.transformTailTrackingInputParameters(airlinecode, flightnumber, schdepdate, depstn,
				arrstn, tailnumber);
	}

	/*
	 * Method to get tailTracking details from flight cosmos
	 * 
	 * @param tailTrackingRQ
	 * 
	 * @throws JbException
	 * 
	 * @return tailtracking details
	 */
	private List<TailTrackingDetail> getTailTrackingCosmosResponse(TailTrackingRequest tailTrackingRQ)
			throws JbException {
		List<TailTrackingDetail> tailTrackingCosmosResponse = flightDomainService
				.getTailTrackingResponse(tailTrackingRQ.getTailNumber(), tailTrackingRQ.getSchDepDate());
		if (CollectionUtils.isEmpty(tailTrackingCosmosResponse)) {
			throw new JbException(HttpStatus.NOT_FOUND, TailTrackingErrorCodes.BETTFUNC1012.toString(),
					MDC.get(TailTrackingConstants.TRANSACTION_ID.toString()));
		} else {
			removeSearchedCancelledFlights(tailTrackingCosmosResponse, tailTrackingRQ);
			sortTailTrackingCosmosResponse(tailTrackingCosmosResponse);
			validateSFLBusinessCheck(tailTrackingCosmosResponse, tailTrackingRQ);
		}
		return tailTrackingCosmosResponse;
	}

	/*
	 * Method to sort tailTracking cosmos response based on current departure date
	 * time
	 * 
	 * @param tailTrackingCosmosResponse
	 */
	private void sortTailTrackingCosmosResponse(List<TailTrackingDetail> tailTrackingCosmosResponse) {
		tailTrackingCosmosResponse.sort((tailTrackingRepo1,
				tailTrackingRepo2) -> (int) JbDateTimeUtil.getDateTimeDiffInMins(
						tailTrackingRepo1.getFlight().getScheduledFlightLeg().getCurrentFlightLeg()
								.getCurrentDepartureDateTime(),
						tailTrackingRepo2.getFlight().getScheduledFlightLeg().getCurrentFlightLeg()
								.getCurrentDepartureDateTime()));
	}

	/**
	 * This Method is used for filtering cancelled flight from the cosmos response
	 * 
	 * @param tailTrackingRQ
	 * 
	 * @param List<TailTrackingRepo>
	 * 
	 * @throws JbException
	 */
	private void removeSearchedCancelledFlights(List<TailTrackingDetail> tailTrackingCosmosResponse,
			TailTrackingRequest tailTrackingRQ) throws JbException {
		List<TailTrackingDetail> listCancelledFlight = new ArrayList<>();
		tailTrackingCosmosResponse.removeIf((TailTrackingDetail tailTrackingRepo) -> {
			boolean cancelledFlight = (tailTrackingRepo.getFlight().getScheduledFlightLeg().getCurrentFlightLeg()
					.getStatus().contains(TailTrackingConstants.AFT_CANCELLED.getValue())
					&& StringUtils.isBlank(tailTrackingRepo.getFlight().getScheduledFlightLeg().getCurrentFlightLeg()
							.getCurrentDepartureDateTime()));
			if (cancelledFlight && StringUtils.equalsIgnoreCase(tailTrackingRQ.getFlightNumber(),
					tailTrackingRepo.getFlight().getFlightNumber())) {
				listCancelledFlight.add(tailTrackingRepo);
			}
			return cancelledFlight;
		});

		if (CollectionUtils.isNotEmpty(listCancelledFlight)) {
			LOGGER.error(String.format("Flights are cancelled for request %s", tailTrackingRQ)).log();
			throw new JbException(HttpStatus.BAD_REQUEST, TailTrackingErrorCodes.BETTFUNC1010.getCode(),
					MDC.get(TailTrackingConstants.TRANSACTION_ID.toString()));
		}
	}

	/**
	 * Getting Current date/time by comparing input flight number to the response's
	 * flight number, If both are not matched, it will throw appropriate exception
	 * else it will get respective current departure date.
	 * 
	 * @param tailTrackingCosmosResponse
	 * 
	 * @return List<TailTrackingRepo>
	 * @throws JbException
	 */
	private String validateFlightNumberBusinessCheck(List<TailTrackingDetail> tailTrackingCosmosResponse,
			TailTrackingRequest tailTrackingRQ) throws JbException {
		for (TailTrackingDetail tailTrackingRepo : tailTrackingCosmosResponse) {
			ScheduledFlightLeg sfl = tailTrackingRepo.getFlight().getScheduledFlightLeg();
			if (StringUtils.equalsIgnoreCase(tailTrackingRQ.getFlightNumber(),
					tailTrackingRepo.getFlight().getFlightNumber())) {
				if (StringUtils.isNotBlank(sfl.getCurrentFlightLeg().getCurrentDepartureDateTime())
						&& StringUtils.equalsIgnoreCase(tailTrackingRQ.getSchDepDate(), sfl.getSchLocalDepDate())
						&& (StringUtils.equalsIgnoreCase(tailTrackingRQ.getDepStn(), sfl.getSchDepStnCode())
								|| StringUtils.equalsIgnoreCase(tailTrackingRQ.getDepStn(),
										sfl.getCurrentFlightLeg().getCurrentDepStnCode()))) {
					return sfl.getCurrentFlightLeg().getCurrentDepartureDateTime();
				}
			}

		}
		LOGGER.error(String.format("Input flightnumber %s does not match with flight number in cosmos response",
				tailTrackingRQ.getFlightNumber())).log();
		throw new JbException(HttpStatus.BAD_REQUEST, TailTrackingErrorCodes.BETTFUNC1010.getCode(),
				MDC.get(TailTrackingConstants.TRANSACTION_ID.toString()));

	}

	/**
	 * Creating SFL key from the request (Airline Code, Schedule dep date,flight
	 * Number and Dep.station code) and comparing it to SFL keys of response. if it
	 * is not found in response, gives appropriate message.
	 * 
	 * @param List<TailTrackingRepo>
	 * 
	 * @throws JbException
	 */
	private void validateSFLBusinessCheck(List<TailTrackingDetail> tailTrackingCosmosResponse,
			TailTrackingRequest tailTrackingRQ) throws JbException {
		String[] depDate = tailTrackingRQ.getSchDepDate().split("-");
		String sflKeyRQ = tailTrackingRQ.getAirlineCode() + tailTrackingRQ.getFlightNumber() + depDate[0] + depDate[1]
				+ depDate[2] + tailTrackingRQ.getDepStn();
		String sflKey = validateSFLKey(sflKeyRQ, tailTrackingCosmosResponse);
		if (StringUtils.equalsIgnoreCase(sflKey, TailTrackingConstants.FALSE.getValue())) {
			LOGGER.error(String.format("SFL key in request %s not found in response %s", sflKeyRQ, sflKey)).log();
			throw new JbException(HttpStatus.BAD_REQUEST, TailTrackingErrorCodes.BETTFUNC1009.getCode(),
					MDC.get(TailTrackingConstants.TRANSACTION_ID.toString()));
		}
	}

	/**
	 * Validating SFL key from the request.
	 * 
	 * @param sflKeyRQ
	 * 
	 * @param tailTrackingCosmosResponse
	 * 
	 * @return String
	 */
	private String validateSFLKey(String sflKeyRQ, List<TailTrackingDetail> tailTrackingCosmosResponse) {
		String sflKey = TailTrackingConstants.FALSE.getValue();
		String sflKeyRS = null;
		String sflKeyRS1 = null;
		String sflKeyRS2 = null;
		for (TailTrackingDetail tailTrackingRepo : tailTrackingCosmosResponse) {
			ScheduledFlightLeg sfl = tailTrackingRepo.getFlight().getScheduledFlightLeg();
			if (StringUtils.isNotBlank(sfl.getSchLocalDepDate())) {
				String[] schDepDate = sfl.getSchLocalDepDate().split("-");
				sflKeyRS = tailTrackingRepo.getFlight().getFlightCarrierCode()
						+ tailTrackingRepo.getFlight().getFlightNumber() + schDepDate[0] + schDepDate[1] + schDepDate[2];
				sflKeyRS1 = sflKeyRS + sfl.getSchDepStnCode();
				sflKeyRS2 = sflKeyRS + sfl.getCurrentFlightLeg().getCurrentDepStnCode();
			}
			if (sflKeyRQ.equalsIgnoreCase(sflKeyRS1) || sflKeyRQ.equalsIgnoreCase(sflKeyRS2)) {
				sflKey = TailTrackingConstants.TRUE.getValue();

			}
		}
		return sflKey;
	}
}
