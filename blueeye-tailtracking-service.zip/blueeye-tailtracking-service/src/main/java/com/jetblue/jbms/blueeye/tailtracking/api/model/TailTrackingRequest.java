
package com.jetblue.jbms.blueeye.tailtracking.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TailTrackingRequest {

	private String airlineCode;
	private String flightNumber;
	private String schDepDate;
	private String depStn;
	private String arrStn;
	private String tailNumber;

	public String getAirlineCode() {
		return airlineCode;
	}

	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getSchDepDate() {
		return schDepDate;
	}

	public void setSchDepDate(String schDepDate) {
		this.schDepDate = schDepDate;
	}

	public String getDepStn() {
		return depStn;
	}

	public void setDepStn(String depStn) {
		this.depStn = depStn;
	}

	public String getArrStn() {
		return arrStn;
	}

	public void setArrStn(String arrStn) {
		this.arrStn = arrStn;
	}

	public String getTailNumber() {
		return tailNumber;
	}

	public void setTailNumber(String tailNumber) {
		this.tailNumber = tailNumber;
	}
	
	@Override
	public String toString() {
		return "TailTrackingRequest: [ Flightnumber: "+flightNumber+" Depstn: "+depStn+" Tail number: "+tailNumber+" ]";
	}

}
