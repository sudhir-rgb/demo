
package com.jetblue.jbms.blueeye.tailtracking.api.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TailTrackingDetails {

	@JsonProperty("PrevDayFlight")
	private List<FlightDetails> prevDayFlight;
	@JsonProperty("PastFlights")
    private List<FlightDetails> pastFlights;
    @JsonProperty("Current")
    private List<FlightDetails> current;
    @JsonProperty("FutureFlights")
    private List<FlightDetails> future;
	@JsonProperty("NextDayFlight")
	private List<FlightDetails> nextDayFlight;
   
	@JsonProperty("PastFlights")
    public List<FlightDetails> getPastFlights() {
        return pastFlights;
    }

    @JsonProperty("PastFlights")
    public void setPastFlights(List<FlightDetails> pastFlights) {
        this.pastFlights = pastFlights;
    }

    @JsonProperty("Current")
    public List<FlightDetails> getCurrent() {
        return current;
    }

    @JsonProperty("Current")
    public void setCurrent(List<FlightDetails> current) {
        this.current = current;
    }

	public List<FlightDetails> getFuture() {
		return future;
	}

	public void setFuture(List<FlightDetails> future) {
		this.future = future;
	}
	public List<FlightDetails> getPrevDayFlight() {
		return prevDayFlight;
	}

	public void setPrevDayFlight(List<FlightDetails> prevDayFlight) {
		this.prevDayFlight = prevDayFlight;
	}

	public List<FlightDetails> getNextDayFlight() {
		return nextDayFlight;
	}

	public void setNextDayFlight(List<FlightDetails> nextDayFlight) {
		this.nextDayFlight = nextDayFlight;
	}
}
