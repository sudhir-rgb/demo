/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosNoDataFoundException;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosTechnicalException;
import com.jetblue.jbms.cosmos.common.ref.model.AcftTailDesignTypeDocument;
import com.jetblue.jbms.cosmos.common.ref.model.Aircraft;
import com.jetblue.jbms.cosmos.common.ref.service.impl.RefCosmosCommonServiceImpl;

/**
 * @author TBhorkar
 * 
 *         Class to call reference domain to fetch Aircraft information
 */
@Service
public class ReferenceDomainService {

	@Autowired
	private RefCosmosCommonServiceImpl referenceCosmosService;

	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDomainService.class);

	/*
	 * Method calls reference domain to fetch aircraft details by tail number
	 * 
	 * @param tailNumber
	 * 
	 * @throws RefCosmosTechnicalException
	 * 
	 * @throws RefCosmosNoDataFoundException
	 * 
	 * @return Aircraft details
	 */
	@Cacheable("acftByTailNumberCache")
	public Map<String,List<Aircraft>> getAllAircrafts()
			throws RefCosmosTechnicalException, RefCosmosNoDataFoundException {
		LOGGER.info("Fetching aircraft details from reference domain").log();
		return referenceCosmosService.getAllAircraft().stream().filter(Objects::nonNull)
				.collect(Collectors.groupingBy(Aircraft::getAcftTailNumber));
	}

	/*
	 * Method calls reference domain to fetch tail design details list
	 * 
	 * @throws RefCosmosTechnicalException
	 * 
	 * @return List<AcftTailDesignTypeDocument>
	 */
	@Cacheable("tailDesignDetailsCache")
	public Map<String,List<AcftTailDesignTypeDocument>> getTailDesignDetails() throws RefCosmosTechnicalException {
		LOGGER.info("Fetching tail design details from reference domain in caseof cache miss").log();
		return new TreeMap<>(referenceCosmosService.getAcftTailDesignTypeQuery().stream().filter(Objects::nonNull)
				.filter(x -> Objects.nonNull(x.getAcftTailDesignTypeCode()))
				.collect(Collectors.groupingBy(AcftTailDesignTypeDocument::getAcftTailDesignTypeCode)));
	}
}
