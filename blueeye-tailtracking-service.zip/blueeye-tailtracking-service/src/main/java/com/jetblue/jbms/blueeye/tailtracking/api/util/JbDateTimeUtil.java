package com.jetblue.jbms.blueeye.tailtracking.api.util;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class JbDateTimeUtil {
	
	/**
	 * @param currentDepDateTime1
	 * @param currentDepDateTime2
	 * @return
	 */
	public static long getDateTimeDiffInMins(String currentDepDateTime1, String currentDepDateTime2) {
		if (null != currentDepDateTime1 && null != currentDepDateTime2) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(TailTrackingConstants.DATE_TIME_FORMAT.getValue());
			ZonedDateTime currentDepDateTimeZDT1 = ZonedDateTime.parse(currentDepDateTime1, formatter);
			ZonedDateTime currentDepDateTimeZDT2 = ZonedDateTime.parse(currentDepDateTime2, formatter);
			return currentDepDateTimeZDT2.toInstant().until(currentDepDateTimeZDT1.toInstant(), ChronoUnit.MINUTES);
		} else {
			return -1;
		}
	}

	// This is used to get the previous departure date 
	public static String getPrevDepDate(String schDepDate) {
		DateTimeFormatter dateFormate = DateTimeFormatter.ofPattern(TailTrackingConstants.DATE_TIME_FORMAT.getValue());
		schDepDate += TailTrackingConstants.TIME.getValue();
		ZonedDateTime currentDateTime = ZonedDateTime.parse(schDepDate,dateFormate);
		ZonedDateTime date = currentDateTime.minusDays(1);
		return date.toString().substring(0, 10);
	}
	
	// This is used to get the next departure date 
	public static String getNextDepDate(String schDepDate) {
		DateTimeFormatter dateFormate = DateTimeFormatter.ofPattern(TailTrackingConstants.DATE_TIME_FORMAT.getValue());
		schDepDate += TailTrackingConstants.TIME.getValue();
		ZonedDateTime currentDateTime = ZonedDateTime.parse(schDepDate,dateFormate);
		ZonedDateTime date = currentDateTime.plusDays(1);
		return date.toString().substring(0, 10);
	}
}
