/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author TBhorkar
 * 
 */
public class AircraftDetails {

	@JsonProperty("tailDesignUrl")
	private String tailDesignUrl;
	@JsonProperty("acRegNumber")
	private String acRegNumber;
	@JsonProperty("tailNumber")
	private String tailNumber;
	@JsonProperty("acName")
	private String acName;

	public String getTailDesignUrl() {
		return tailDesignUrl;
	}

	public void setTailDesignUrl(String tailDesignUrl) {
		this.tailDesignUrl = tailDesignUrl;
	}

	public String getAcRegNumber() {
		return acRegNumber;
	}

	public void setAcRegNumber(String acRegNumber) {
		this.acRegNumber = acRegNumber;
	}

	public String getTailNumber() {
		return tailNumber;
	}

	public void setTailNumber(String tailNumber) {
		this.tailNumber = tailNumber;
	}

	public String getAcName() {
		return acName;
	}

	public void setAcName(String acName) {
		this.acName = acName;
	}


}
