package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.StringUtils;

public class DepStnConstraint implements ConstraintValidator<DepStnValidator, String> {

	private static final Logger LOGGER = LoggerFactory.getLogger(DepStnConstraint.class);

	private String sizeErrorMessage;

	/*
	 * * (non-Javadoc)
	 * 
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
	public void initialize(final DepStnValidator constraintAnnotation) {
		sizeErrorMessage = constraintAnnotation.sizeErrorMessage();
	}

	/*
	 * * (non-Javadoc)
	 * 
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */

	@Override
	public boolean isValid(String depStnCode, ConstraintValidatorContext context) {
		String regex = "^[A-Z]{3,3}$";

		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(depStnCode);

		if (StringUtils.isBlank(depStnCode)) {
			return false;
		} else if (!matcher.matches()) {
			LOGGER.error(String.format("Dep stn pattern matchng error depstn: %s pattern: %s", depStnCode, regex))
					.log();
			context.buildConstraintViolationWithTemplate(sizeErrorMessage).addConstraintViolation()
					.disableDefaultConstraintViolation();
			return false;
		}
		return true;
	}
}
