package com.jetblue.jbms.blueeye.tailtracking.api.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.interceptor.SimpleKeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.spring.cache.HazelcastCacheManager;
import com.jetblue.jbms.blueeye.tailtracking.api.service.ReferenceDomainService;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosNoDataFoundException;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosTechnicalException;

@EnableScheduling
@Configuration
public class CacheConfig implements CommandLineRunner {

	@Autowired
	private ReferenceDomainService refDomainService;

	private HazelcastCacheManager cacheManager;

	@Bean
	public CacheManager cacheManager() {
		Config cfg = new Config();
		HazelcastInstance instance = Hazelcast.newHazelcastInstance(cfg);
		cacheManager = new HazelcastCacheManager(instance);
		return cacheManager;
	}

	@Bean
	public KeyGenerator keyGenerator() {
		return new SimpleKeyGenerator();
	}
	
	@Override
    public void run(String... args) throws Exception {
		refDomainService.getAllAircrafts();
		refDomainService.getTailDesignDetails();
    }

	@Scheduled(cron = "${tail.tracking.cache.interval.cron}")
	public void evictAllcachesAtIntervals() throws RefCosmosTechnicalException, RefCosmosNoDataFoundException {
		cacheManager.getCacheNames().stream().forEach(cacheName -> cacheManager.getCache(cacheName).clear());
		refDomainService.getAllAircrafts();
		refDomainService.getTailDesignDetails();
	}

}
