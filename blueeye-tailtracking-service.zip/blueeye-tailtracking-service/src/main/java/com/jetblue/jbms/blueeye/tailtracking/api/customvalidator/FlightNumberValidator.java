package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Payload;


@javax.validation.Constraint(validatedBy = { FlightNumberConstraint.class })
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RUNTIME)
public @interface FlightNumberValidator {

	String message() default "BETTFUNC1004";
	String lengthErrorMessage() default "BETTFUNC1007";
	String numberErrorMessage() default "BETTFUNC1008";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
    
}
