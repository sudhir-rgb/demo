package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import javax.validation.Payload;

/**
 * The Interface DepStnValidator.
 * 
 * 
 */
@javax.validation.Constraint(validatedBy = { DepStnConstraint.class })
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RUNTIME)
public @interface DepStnValidator {

	String message() default "BETTFUNC1004";
	String sizeErrorMessage() default "BETTFUNC1003";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
    
}
