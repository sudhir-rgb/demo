package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingConstants;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.StringUtils;

public class DateConstraint implements ConstraintValidator<DateValidator, String>{
	private static final Logger Log = LoggerFactory.getLogger(DateConstraint.class);
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
    public void initialize(DateValidator date) {
		//Not Needed
    }

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
	public boolean isValid(String date, ConstraintValidatorContext context) {
		DateFormat dateFormate = new SimpleDateFormat(TailTrackingConstants.DATE_FORMAT.getValue());
		try {
			if (StringUtils.isNotEmpty(date)) {
				dateFormate.setLenient(Boolean.FALSE);
				dateFormate.parse(date);
			}
		} catch (Exception exp) {
			Log.error(String.format("Date not passed in correct format. Passed date: %s. Exception: %s", date, exp));
			return false;
		}
		return true;
		
	}

}