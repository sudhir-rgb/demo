package com.jetblue.jbms.blueeye.tailtracking.api.transform;

import static com.jetblue.jbms.common.log.Utils.unwrap;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;

import com.jetblue.jbms.blueeye.tailtracking.api.model.AircraftDetails;
import com.jetblue.jbms.blueeye.tailtracking.api.model.FlightDetails;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingDetails;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingDetailsResponse;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingRequest;
import com.jetblue.jbms.blueeye.tailtracking.api.util.JbDateTimeUtil;
import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingConstants;
import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingErrorCodes;
import com.jetblue.jbms.common.exception.JbException;
import com.jetblue.jbms.common.flight.model.ActualFlightLeg;
import com.jetblue.jbms.common.flight.model.CurrentFlightLeg;
import com.jetblue.jbms.common.flight.model.ScheduledFlightLeg;
import com.jetblue.jbms.common.flight.model.TailTrackingDetail;
import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;
import com.jetblue.jbms.cosmos.common.ref.model.AcftTailDesignTypeDocument;
import com.jetblue.jbms.cosmos.common.ref.model.Aircraft;

/**
 * The Class for Transform Implementation
 * 
 * @author RJain & RKukadeja
 *
 */

public final class TailTrackingTransform {

	private TailTrackingTransform() {
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(TailTrackingTransform.class);

	/**
	 * @return Tail Tracking Request
	 *
	 */

	public static TailTrackingRequest transformTailTrackingInputParameters(String airlinecode, String flightnumber,
			String schdepdate, String depstn, String arrstn, String tailnumber) {
		String updatedFlightNumber = null;
		TailTrackingRequest tailTrackingRQ = new TailTrackingRequest();
		if (StringUtils.isNotBlank(flightnumber)) {
			updatedFlightNumber = StringUtils.leftPad(flightnumber, 4, "0");
		}
		tailTrackingRQ.setAirlineCode(
				StringUtils.isEmpty(airlinecode) ? TailTrackingConstants.CARRIER_CODE.getValue() : airlinecode);

		tailTrackingRQ.setSchDepDate(schdepdate);
		tailTrackingRQ.setDepStn(depstn);
		tailTrackingRQ.setFlightNumber(updatedFlightNumber);
		tailTrackingRQ.setTailNumber(tailnumber);
		tailTrackingRQ.setArrStn(arrstn);
		return tailTrackingRQ;
	}

	/*
	 * Method to get tailTrackingResponse
	 * 
	 * @param listTailTrackingFlights
	 * 
	 * @param currFlightDepDate
	 * 
	 * @param tailTrackingRequest
	 * 
	 * @param aircraft
	 * 
	 * @param acftTailDesignDetailsList
	 * 
	 * @return TailTrackingDetailsResponse
	 * 
	 * @throws JbException
	 */
	public static TailTrackingDetailsResponse transformTailTrackingResponse(
			final List<TailTrackingDetail> listTailTrackingFlights, String currFlightDepDate,
			final TailTrackingRequest tailTrackingRQ, final Aircraft aircraft,
			final Map<String,List<AcftTailDesignTypeDocument>> acftTailDesignDetailsMap) throws JbException {
		LOGGER.info("Transforming Cosmos response to tail tracking response model").log();
		TailTrackingDetailsResponse tailTrackingDetailsResponse = new TailTrackingDetailsResponse();
		TailTrackingDetails tailTrackingDetails = new TailTrackingDetails();
		List<FlightDetails> listPastFlightDetails = new ArrayList<>();
		List<FlightDetails> listCurrentFlightDetails = new ArrayList<>();
		List<FlightDetails> listfutureFlightDetails = new ArrayList<>();
		try {
			for (TailTrackingDetail tailTrackingRepo : listTailTrackingFlights) {
				FlightDetails flightDetails = getFlightDetailsFromCosmosResponse(tailTrackingRepo);
				ScheduledFlightLeg sfl = tailTrackingRepo.getFlight().getScheduledFlightLeg();
				setCFLDetails(flightDetails, sfl.getCurrentFlightLeg());
				setDepartureAndArrivalVariance(flightDetails, sfl);
				setSubTextDetails(flightDetails, sfl);
				setAircraftDetails(acftTailDesignDetailsMap, aircraft, flightDetails);
				setFlightDetails(flightDetails, currFlightDepDate, sfl.getCurrentFlightLeg(), tailTrackingDetails,
						listPastFlightDetails, listCurrentFlightDetails, listfutureFlightDetails);
			}
			checkPastFlight(listPastFlightDetails, tailTrackingDetails, tailTrackingRQ.getSchDepDate());
			checkFutureFlight(listfutureFlightDetails, tailTrackingDetails, tailTrackingRQ.getSchDepDate());
			tailTrackingDetailsResponse.setTailTrackingDetails(tailTrackingDetails);
		} catch (Exception e) {
			LOGGER.error(String.format(
					"Exception occured while transforming db reponse to tail tracking response model for request %s %s",
					tailTrackingRQ.toString(), ExceptionUtils.getStackTrace(unwrap(e)))).log();
			throw new JbException(HttpStatus.INTERNAL_SERVER_ERROR, TailTrackingErrorCodes.BETTFUNC1005.toString(),
					MDC.get(TailTrackingConstants.TRANSACTION_ID.toString()));
		}
		return tailTrackingDetailsResponse;
	}

	/*
	 * Method to check future flight and set flight details accordingly
	 * 
	 * @param list of flight details
	 * 
	 * @param tailTrackingDetails
	 * 
	 * @param schDepDate
	 */
	private static void checkFutureFlight(List<FlightDetails> listfutureFlightDetails,
			TailTrackingDetails tailTrackingDetails, String schDepDate) {
		List<FlightDetails> nextFlightList = new ArrayList<>();
		List<FlightDetails> futureFlightList = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(listfutureFlightDetails)) {
			for (FlightDetails flightDetails : listfutureFlightDetails) {
				if (StringUtils.isNotBlank(schDepDate) && StringUtils.isNotBlank(flightDetails.getSchDepDateTime())) {
					if (schDepDate.contentEquals(flightDetails.getSchDepDateTime().substring(0, 10))) {
						futureFlightList.add(flightDetails);
						tailTrackingDetails.setFuture(futureFlightList);
					} else {
						checkNextLastFlight(flightDetails, nextFlightList, schDepDate);
					}
				}
			}
		}
		checkFirstFlightFromNextDay(tailTrackingDetails, nextFlightList);

	}

	/*
	 * Method to check past flight and set flight details accordingly
	 * 
	 * @param list of flight details
	 * 
	 * @param tailTrackingDetails
	 * 
	 * @param schDepDate
	 */
	private static void checkPastFlight(List<FlightDetails> listPastFlightDetails,
			TailTrackingDetails tailTrackingDetails, String schDepDate) {
		List<FlightDetails> prevFlightList = new ArrayList<>();
		List<FlightDetails> pastFlightList = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(listPastFlightDetails)) {
			for (FlightDetails flightDetails : listPastFlightDetails) {
				if (StringUtils.isNotBlank(schDepDate) && StringUtils.isNotBlank(flightDetails.getSchDepDateTime())) {
					if (schDepDate.contentEquals(flightDetails.getSchDepDateTime().substring(0, 10))) {
						pastFlightList.add(flightDetails);
						tailTrackingDetails.setPastFlights(pastFlightList);
					} else {
						checkPrevLastFlight(flightDetails, prevFlightList, schDepDate);
					}
				}
			}
		}
		checkLastFlightFromPreviousDay(tailTrackingDetails, prevFlightList);

	}

	/*
	 * Method to check prev day flight and set flight details accordingly
	 * 
	 * @param list of flight details
	 * 
	 * @param tailTrackingDetails
	 * 
	 * @param schDepDate
	 */
	private static void checkPrevLastFlight(FlightDetails flightDetails, List<FlightDetails> prevFlightList,
			String schDepDate) {
		if (JbDateTimeUtil.getPrevDepDate(schDepDate)
				.contentEquals(flightDetails.getSchDepDateTime().substring(0, 10))) {
			prevFlightList.add(flightDetails);
		}
	}

	/*
	 * Method to check next flight and set flight details accordingly
	 * 
	 * @param list of flight details
	 * 
	 * @param tailTrackingDetails
	 * 
	 * @param schDepDate
	 */
	private static void checkNextLastFlight(FlightDetails flightDetails, List<FlightDetails> nextFlightList,
			String schDepDate) {
		if (JbDateTimeUtil.getNextDepDate(schDepDate)
				.contentEquals(flightDetails.getSchDepDateTime().substring(0, 10))) {
			nextFlightList.add(flightDetails);
		}
	}

	/*
	 * Method to check first flight from next day and set flight details accordingly
	 * 
	 * @param list of flight details
	 * 
	 * @param tailTrackingDetails
	 * 
	 */
	private static void checkFirstFlightFromNextDay(TailTrackingDetails tailTrackingDetails,
			List<FlightDetails> nextFlightList) {
		List<FlightDetails> nextDayFlight = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(nextFlightList)) {
			nextFlightList.sort((flight1, flight2) -> {
				return (int) JbDateTimeUtil.getDateTimeDiffInMins(flight1.getMaxDate(), flight2.getMaxDate());
			});
			FlightDetails flightDetails = nextFlightList.get(0);
			nextDayFlight.add(flightDetails);
			tailTrackingDetails.setNextDayFlight(nextDayFlight);
		}
	}

	/*
	 * Method to check last flight from prev day and set flight details accordingly
	 * 
	 * @param list of flight details
	 * 
	 * @param tailTrackingDetails
	 * 
	 */
	private static void checkLastFlightFromPreviousDay(TailTrackingDetails tailTrackingDetails,
			List<FlightDetails> prevFlightList) {
		List<FlightDetails> prevDayFlight = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(prevFlightList)) {
			prevFlightList.sort((flight1, flight2) -> {
				return (int) JbDateTimeUtil.getDateTimeDiffInMins(flight1.getMaxDate(), flight2.getMaxDate());
			});
			FlightDetails flightDetails = prevFlightList.get(prevFlightList.size() - 1);
			prevDayFlight.add(flightDetails);
			tailTrackingDetails.setPrevDayFlight(prevDayFlight);
		}
	}

	/*
	 * Method to set scheduled flight leg details
	 * 
	 * @param tailTracking cosmos response
	 * 
	 * @param currDepDateTime
	 * 
	 * @param tailTrackingDetails
	 * 
	 * @return FlightDetails
	 * 
	 */
	private static FlightDetails getFlightDetailsFromCosmosResponse(TailTrackingDetail tailTrackingRepo) {

		ScheduledFlightLeg sfl = tailTrackingRepo.getFlight().getScheduledFlightLeg();
		FlightDetails flightDetails = new FlightDetails();
		flightDetails.setCarrierCode(tailTrackingRepo.getFlight().getFlightCarrierCode());
		flightDetails.setFlightNumber(tailTrackingRepo.getFlight().getFlightNumber());
		flightDetails.setSchCityPair(sfl.getSchDepStnCode() + "-" + sfl.getSchArrStnCode());
		flightDetails.setSchDepDateTime(sfl.getSchLocalDepDateTime());
		flightDetails.setRon(Boolean.parseBoolean(sfl.getCurrentFlightLeg().getRON()));
		flightDetails.setSchArrDateTime(sfl.getSchArrDateTime());
		return flightDetails;
	}

	/**
	 * Set Current Flight Leg details to response
	 * 
	 * @param FlightDetails
	 * @param CurrentFlightLeg
	 * @return TailTrackingDetailsResponse
	 */
	private static void setCFLDetails(final FlightDetails flightDetails, final CurrentFlightLeg currentFlightLeg) {
		flightDetails.setCurrentCityPair(
				currentFlightLeg.getCurrentDepStnCode() + "-" + currentFlightLeg.getCurrentArrStnCode());
		flightDetails.setCurrentDepDateTime(currentFlightLeg.getCurrentDepartureDateTime());
		flightDetails.setaTA(currentFlightLeg.getActLocalInDateTime());
		flightDetails.setArrGate(currentFlightLeg.getArrGate());
		flightDetails.setDepGate(currentFlightLeg.getDepGate());
		flightDetails.setEstDepDateTime(currentFlightLeg.getEstLocalDepDateTime());
		flightDetails.setStatus(currentFlightLeg.getStatus());
		checkDateBasedOnSTDOrETDOrATD(flightDetails, currentFlightLeg);
	}

	/*
	 * Method to calculate arrival and departure variance
	 *  
	 * arrVar = ATA-STA | depVar = ATD-STD
	 * 
	 * @param flightDetails
	 * 
	 * @param scheduledFlightLeg
	 */
	private static void setDepartureAndArrivalVariance(final FlightDetails flightDetails,
			final ScheduledFlightLeg sfl) {
		flightDetails.setDepVariance(String.valueOf(JbDateTimeUtil.getDateTimeDiffInMins(
				sfl.getCurrentFlightLeg().getCurrentDepartureDateTime(), sfl.getSchLocalDepDateTime())));
		flightDetails.setArrVariance(String.valueOf(JbDateTimeUtil
				.getDateTimeDiffInMins(sfl.getCurrentFlightLeg().getCurrArrDateTime(), sfl.getSchArrDateTime())));
	}

	private static void checkDateBasedOnSTDOrETDOrATD(FlightDetails flightDetails, CurrentFlightLeg currentFlightLeg) {
		if (StringUtils.isNotBlank(currentFlightLeg.getActLocalOutDateTime())) {
			flightDetails.setMaxDate(currentFlightLeg.getActLocalOutDateTime());
		} else if (StringUtils.isNotBlank(currentFlightLeg.getEstLocalDepDateTime())) {
			flightDetails.setMaxDate(currentFlightLeg.getEstLocalDepDateTime());
		} else {
			if (StringUtils.isNotBlank(flightDetails.getSchDepDateTime())) {
				flightDetails.setMaxDate(flightDetails.getSchDepDateTime());
			}
		}
	}

	/**
	 * Set SubText Details to response for Tail Tracking
	 * 
	 * @param FlightDetails
	 * 
	 */
	private static void setSubTextDetails(final FlightDetails flightDetails, ScheduledFlightLeg sfl) {
		boolean subTextIndicator = false;
		if (!validateCancelledFlight(flightDetails, sfl.getCurrentFlightLeg(), subTextIndicator)
				&& !validateDivertedFlight(flightDetails, subTextIndicator, sfl)
				&& !validateStubOriginFlight(flightDetails, subTextIndicator, sfl)
				&& !validatePrevTailFlight(flightDetails, sfl.getCurrentFlightLeg(), subTextIndicator)) {
			flightDetails.setSubTextIndicator(subTextIndicator);
		}
	}

	private static boolean validatePrevTailFlight(FlightDetails flightDetails, CurrentFlightLeg currentFlightLeg,
			boolean subTextIndicator) {
		if ((StringUtils.isNotBlank(currentFlightLeg.getPrevTailNumber())
				&& StringUtils.isNotBlank(currentFlightLeg.getTailNumber())
				&& !StringUtils.equalsIgnoreCase(currentFlightLeg.getPrevTailNumber(),
						currentFlightLeg.getTailNumber()))
				&& !currentFlightLeg.getStatus().contains(TailTrackingConstants.AFT_CANCELLED.getValue())) {
			flightDetails.setSubText(
					TailTrackingConstants.SUBTEXT_PREVTAIL.getValue() + currentFlightLeg.getPrevTailNumber());
			subTextIndicator = true;
			flightDetails.setSubTextIndicator(subTextIndicator);
		}
		return subTextIndicator;
	}

	private static boolean validateStubOriginFlight(FlightDetails flightDetails, boolean subTextIndicator,
			ScheduledFlightLeg sfl) {
		CurrentFlightLeg currentFlightLeg = sfl.getCurrentFlightLeg();
		if (!StringUtils.equalsIgnoreCase(sfl.getSchDepStnCode(), currentFlightLeg.getCurrentDepStnCode())) {
			flightDetails.setSubText(
					TailTrackingConstants.SUBTEXT_ORIGIN.getValue() + currentFlightLeg.getCurrentDepStnCode());
			subTextIndicator = true;
			flightDetails.setSubTextIndicator(subTextIndicator);
		}
		return subTextIndicator;
	}

	private static boolean validateDivertedFlight(FlightDetails flightDetails, boolean subTextIndicator,
			ScheduledFlightLeg sfl) {
		CurrentFlightLeg currentFlightLeg = sfl.getCurrentFlightLeg();
		if ((StringUtils.equalsIgnoreCase(TailTrackingConstants.AFT_DVC_DIVERTED.getValue(),
				currentFlightLeg.getActualFlightType())
				|| StringUtils.equalsIgnoreCase(TailTrackingConstants.AFT_DVH_DIVERTED.getValue(),
						currentFlightLeg.getActualFlightType()))

				&& !StringUtils.equalsIgnoreCase(TailTrackingConstants.SUBTEXT_INFLIGHT.getValue(),
						currentFlightLeg.getStatus())
				&& !StringUtils.equalsIgnoreCase(TailTrackingConstants.SUBTEXT_LANDED.getValue(),
						currentFlightLeg.getStatus())
				&& !StringUtils.equalsIgnoreCase(TailTrackingConstants.SUBTEXT_ARRIVED.getValue(),
						currentFlightLeg.getStatus())
				&& !StringUtils.contains(currentFlightLeg.getStatus(),
						TailTrackingConstants.AFT_CANCELLED.getValue())) {

			ActualFlightLeg actualFlightLeg = sfl.getActualFlightLeg().stream().filter(
					afl -> afl.getActFlightLegSeqNumber().equalsIgnoreCase(currentFlightLeg.getActiveAFLSeqNumber()))
					.findAny().orElse(null);
			if (actualFlightLeg != null) {
				if (actualFlightLeg.getArrStnCode().equalsIgnoreCase(sfl.getSchArrStnCode())) {
					flightDetails.setSubText(
							TailTrackingConstants.SUBTEXT_DIVERTED.getValue() + actualFlightLeg.getDepStnCode());
				} else {
					flightDetails.setSubText(
							TailTrackingConstants.SUBTEXT_DIVERTED.getValue() + actualFlightLeg.getArrStnCode());
				}
				subTextIndicator = true;
				flightDetails.setSubTextIndicator(subTextIndicator);
			}
		}
		return subTextIndicator;
	}

	private static boolean validateCancelledFlight(FlightDetails flightDetails, CurrentFlightLeg currentFlightLeg,
			boolean subTextIndicator) {
		if (StringUtils.isNotBlank(currentFlightLeg.getStatus())
				&& currentFlightLeg.getStatus().contains(TailTrackingConstants.AFT_CANCELLED.getValue())) {
			flightDetails.setSubText(TailTrackingConstants.SUBTEXT_CANCELLED.getValue());
			subTextIndicator = true;
			flightDetails.setSubTextIndicator(subTextIndicator);
		}
		return subTextIndicator;
	}

	/**
	 * Set domain flight Details to the response for Tail Tracking
	 * 
	 * @param TailTrackingDetails
	 * @param List<FlightDetails>
	 * @param List<FlightDetails>
	 * @param List<FlightDetails>
	 * @param List<FlightDetails>
	 * 
	 * @param FlightDetails
	 * @param String
	 * @param List<CurrentFlightLeg>
	 * 
	 * @return TailTrackingDetailsResponse
	 *
	 */
	private static void setFlightDetails(FlightDetails flightDetails, String currFlightDepDate,
			final CurrentFlightLeg currentFlightLeg, final TailTrackingDetails tailTrackingDetails,
			final List<FlightDetails> listPastFlightDetails, final List<FlightDetails> listCurrentFlightDetails,
			final List<FlightDetails> listfutureFlightDetails) {
		DateTimeFormatter dateTimeFormat = DateTimeFormatter
				.ofPattern(TailTrackingConstants.DATE_TIME_FORMAT.getValue());
		int i = ZonedDateTime.parse(currFlightDepDate, dateTimeFormat).toInstant().compareTo(
				ZonedDateTime.parse(currentFlightLeg.getCurrentDepartureDateTime(), dateTimeFormat).toInstant());
		if (i == 0) {
			listCurrentFlightDetails.add(flightDetails);
			tailTrackingDetails.setCurrent(listCurrentFlightDetails);
		} else if (i > 0) {
			flightDetails.setAircraftResponse(null);
			listPastFlightDetails.add(flightDetails);
		} else if (i < 0) {
			flightDetails.setAircraftResponse(null);
			listfutureFlightDetails.add(flightDetails);
		}
	}

	private static void setAircraftDetails(final Map<String, List<AcftTailDesignTypeDocument>> acftTailDesignDetailsMap,
			final Aircraft aircraft, FlightDetails flightDetails) {
		AircraftDetails aircraftDetails = new AircraftDetails();
		if (Objects.nonNull(aircraft)) {
			aircraftDetails.setAcName(aircraft.getAcftName());
			aircraftDetails.setAcRegNumber(aircraft.getAcftRegNumber());
			aircraftDetails.setTailNumber(aircraft.getAcftTailNumber());
			if (Objects.nonNull(acftTailDesignDetailsMap)
					&& Objects.nonNull(acftTailDesignDetailsMap.get(aircraft.getAcftTailDesignTypeCode()))) {
				AcftTailDesignTypeDocument acftTailDesignTypeDocument = acftTailDesignDetailsMap
						.get(aircraft.getAcftTailDesignTypeCode()).get(0);
				if (Objects.nonNull(acftTailDesignTypeDocument)) {
					aircraftDetails.setTailDesignUrl(acftTailDesignTypeDocument.getAcftTailDesignURL());
				}
			}
		}
		flightDetails.setAircraftResponse(aircraftDetails);
	}

}
