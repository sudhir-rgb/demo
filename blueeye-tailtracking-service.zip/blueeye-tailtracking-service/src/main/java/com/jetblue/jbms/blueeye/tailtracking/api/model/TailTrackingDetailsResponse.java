
package com.jetblue.jbms.blueeye.tailtracking.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "TailTrackingDetails"
})
public class TailTrackingDetailsResponse {

	@JsonProperty("TailTrackingDetails")
	private TailTrackingDetails tailTrackingDetails;

	public TailTrackingDetails getTailTrackingDetails() {
		return tailTrackingDetails;
	}

	public void setTailTrackingDetails(TailTrackingDetails tailTrackingDetails) {
		this.tailTrackingDetails = tailTrackingDetails;
	}

	
	
		   }
