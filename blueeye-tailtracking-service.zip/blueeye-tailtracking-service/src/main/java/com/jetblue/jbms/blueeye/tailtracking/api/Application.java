package com.jetblue.jbms.blueeye.tailtracking.api;

import static com.jetblue.jbms.common.log.Utils.unwrap;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.jetblue.jbms.common.log.CustomLogTelemetryClientProxy;
import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;
import com.jetblue.jbms.common.logconfiguration.LogConfiguration;


import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author RJain & RKukadeja Main class for BootStrapping Spring
 *
 */
@SpringBootApplication
@EnableSwagger2
@ComponentScan("com.jetblue.jbms")
@EnableCaching
@EnableScheduling
public class Application {

	@Value("${app.build.number}")
	private String buildNum;

	private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);

	public static void main(String[] args) throws Exception {
		try {
			LogConfiguration.setLogger();
			LogConfiguration.initializeTelemetry();
			SpringApplication.run(Application.class, args);
			LOGGER.info("Blueeye TailTracking Service started successfully!!!" + System.getenv("B6_BUILD_ID")).log();
		} catch (Exception ex) {
			Throwable realcause = unwrap(ex);
			LOGGER.error("Error starting TailTracking Service - " + ExceptionUtils.getMessage(realcause) + " | "
					+ ExceptionUtils.getStackTrace(realcause)).log();
			CustomLogTelemetryClientProxy.flushTelemetry();
		}
	}

	/**
	 * Enable SWAGGER 2
	 * 
	 * @return {@link Docket}
	 */
	@Bean
	public Docket newsApi() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.jetblue.jbms.blueeye.tailtracking.api")).build()
				.apiInfo(apiInfo());
	}

	/**
	 * Setting SWAGGER description for Micro Service
	 * 
	 * @return {@link ApiInfo}
	 */
	private ApiInfo apiInfo() {
		Contact ct = new Contact("Web Services Product Engineering", "https://www.jetblue.com", "");
		return new ApiInfoBuilder().title("Tail Tracking Service").description("Search flights with tail number")
				.license("JetBlue Proprietary").termsOfServiceUrl("http://www.jetblue.com").contact(ct)
				.version("1.0" + " Build " + buildNum).build();
	}

}
