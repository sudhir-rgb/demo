
package com.jetblue.jbms.blueeye.tailtracking.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ATA", "aircraftResponse","schCityPair", "currentCityPair", "carrierCode", "flightNumber", "schDepDateTime",
		"currentDepDateTime","estDepDateTime","schArrDateTime","rON", "subTextIndicator", "subText","status" })
public class FlightDetails {

	@JsonProperty("ATA")
	private String aTA;
	@JsonIgnore
	private String maxDate;
	private String schCityPair;
	private String currentCityPair;
	private String carrierCode;
	private String flightNumber;
	private String schDepDateTime;
	private String currentDepDateTime;
	private Boolean ron;
	private Boolean subTextIndicator;
	private String subText;
	private AircraftDetails aircraftResponse;
	private String arrGate;
	private String depGate;
	private String schArrDateTime;
	private String estDepDateTime;
	private String status;
	private String depVariance;
	private String arrVariance;
	

	public String getSchCityPair() {
		return schCityPair;
	}

	public void setSchCityPair(String schCityPair) {
		this.schCityPair = schCityPair;
	}

	public String getCurrentCityPair() {
		return currentCityPair;
	}

	public void setCurrentCityPair(String currentCityPair) {
		this.currentCityPair = currentCityPair;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}


	public String getFlightNumber() {
		return flightNumber;
	}


	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}


	public String getSchDepDateTime() {
		return schDepDateTime;
	}

	public void setSchDepDateTime(String schDepDateTime) {
		this.schDepDateTime = schDepDateTime;
	}


	public String getCurrentDepDateTime() {
		return currentDepDateTime;
	}


	public void setCurrentDepDateTime(String currentDepDateTime) {
		this.currentDepDateTime = currentDepDateTime;
	}
	

	public String getaTA() {
		return aTA;
	}

	public void setaTA(String aTA) {
		this.aTA = aTA;
	}

	public Boolean getSubTextIndicator() {
		return subTextIndicator;
	}

	public void setSubTextIndicator(Boolean subTextIndicator) {
		this.subTextIndicator = subTextIndicator;
	}

	public String getSubText() {
		return subText;
	}

	public void setSubText(String subText) {
		this.subText = subText;
	}
	public Boolean getRon() {
		return ron;
	}

	public void setRon(Boolean ron) {
		this.ron = ron;
	}

	public String getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(String maxDate) {
		this.maxDate = maxDate;
	}

	public AircraftDetails getAircraftResponse() {
		return aircraftResponse;
	}

	public void setAircraftResponse(AircraftDetails aircraftResponse) {
		this.aircraftResponse = aircraftResponse;
	}

	public String getEstDepDateTime() {
		return estDepDateTime;
	}

	public void setEstDepDateTime(String estDepDateTime) {
		this.estDepDateTime = estDepDateTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getArrGate() {
		return arrGate;
	}
	
	public void setArrGate(String arrGate) {
		this.arrGate = arrGate;
	}

	public String getDepVariance() {
		return depVariance;
	}

	public void setDepVariance(String depVariance) {
		this.depVariance = depVariance;
	}

	public String getArrVariance() {
		return arrVariance;
	}

	public void setArrVariance(String arrVariance) {
		this.arrVariance = arrVariance;
	}

	public String getDepGate() {
		return depGate;
	}

	public void setDepGate(String depGate) {
		this.depGate = depGate;
	}

	public String getSchArrDateTime() {
		return schArrDateTime;
	}

	public void setSchArrDateTime(String schArrDateTime) {
		this.schArrDateTime = schArrDateTime;
	}


}
