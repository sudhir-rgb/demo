package com.jetblue.jbms.blueeye.tailtracking.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.CarrierCodeValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.DateValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.DepStnValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.FlightNumberValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.TailNumberValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingDetailsResponse;
import com.jetblue.jbms.blueeye.tailtracking.api.service.TailTrackingService;
import com.jetblue.jbms.common.advice.ApiExceptionHandlerAdvice;
import com.jetblue.jbms.common.exception.JbException;
import com.jetblue.jbms.common.log.LoggerFactory;
import com.jetblue.jbms.common.log.logger.Logger;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Controller Implementation Class
 * 
 * @author RJain & RKukadeja
 *
 */
@RestController
@Validated
@RequestMapping(value = "/blueeye/flight/")
public class TailTrackingController extends ApiExceptionHandlerAdvice {

	@Autowired
	private TailTrackingService tailTrackingService;

	private static final Logger LOGGER = LoggerFactory.getLogger(TailTrackingController.class);

	/**
	 * Endpoint to get tailtracking details
	 * 
	 * @return tailtrackingdetailsresponse
	 * 
	 * @throws JbException
	 * 
	 */
	@ApiOperation(value = "Get Tail Tracking Details", notes = "Get Tail Tracking Details")
	@GetMapping(path = "tailtracking", produces = "application/json")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = TailTrackingDetailsResponse.class),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 404, message = "Not found"), @ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<TailTrackingDetailsResponse> getTailTrackingDetails(
			@ApiParam(name = "airlinecode", value = "Airline Code", required = false) @CarrierCodeValidator @RequestParam(required = false) String airlinecode,
			@ApiParam(name = "flightnumber", value = "Flight Number", required = true) @FlightNumberValidator @RequestParam(required = true) String flightnumber,
			@ApiParam(name = "schdepdate", value = "Schedule Departure Date (yyyy-mm-dd)", required = true) @DateValidator @RequestParam String schdepdate,
			@ApiParam(name = "depstn", value = "Departure Station", required = true) @DepStnValidator @RequestParam(required = true) String depstn,
			@ApiParam(name = "arrstn", value = "Arrival Station", required = false) @RequestParam(required = false) String arrstn,
			@ApiParam(name = "tailnumber", value = "Tail Number", required = true) @TailNumberValidator @RequestParam(required = true) String tailnumber)
			throws JbException {

		LOGGER.info("TAIL TRACKING API :" + "airlinecode :" + airlinecode + "flightnumber:" + flightnumber
				+ "schdepdate:" + schdepdate + "depstn:" + depstn + "arrstn:" + arrstn + "tailnumber:" + tailnumber)
				.log();

		return new ResponseEntity<>(tailTrackingService.getTailTrackingDetails(airlinecode, flightnumber, schdepdate,
				depstn, arrstn, tailnumber), HttpStatus.OK);

	}
}
