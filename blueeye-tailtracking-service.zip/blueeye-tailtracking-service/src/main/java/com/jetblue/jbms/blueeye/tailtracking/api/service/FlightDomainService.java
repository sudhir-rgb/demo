/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jetblue.jbms.common.exception.JbException;
import com.jetblue.jbms.common.flight.model.TailTrackingDetail;
import com.jetblue.jbms.common.flight.service.FlightInformationService;

/**
 * @author TBhorkar
 * 
 *         Class to call flight cosmos to fetch flight information
 */
@Service
public class FlightDomainService {

	@Autowired
	private FlightInformationService flightInfoService;

	
	/*
	 * Method calls flight cosmos to fetch tailtracking information
	 * 
	 * @param tailNumber
	 * 
	 * @param schDepDate
	 * 
	 * @throws JbException
	 * 
	 * @return tailtracking details
	 */
	public List<TailTrackingDetail> getTailTrackingResponse(String tailNumber, String schDepDate) throws JbException {
		return flightInfoService.getTailTrackingResponse(tailNumber, schDepDate);
	}
}
