package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.StringUtils;

public class CarrierCodeConstraint implements ConstraintValidator<CarrierCodeValidator, String>{

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
    public void initialize(CarrierCodeValidator code) {
		//Not needed
    }

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.
	 * Annotation)
	 */
	@Override
	public boolean isValid(String code, ConstraintValidatorContext context) {
		return StringUtils.isEmpty(code) || (StringUtils.isNotBlank(code) && code.equals("B6"));
	}

}