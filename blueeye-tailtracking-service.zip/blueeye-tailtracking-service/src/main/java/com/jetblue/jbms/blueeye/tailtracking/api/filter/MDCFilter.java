package com.jetblue.jbms.blueeye.tailtracking.api.filter;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingConstants;

@Component
public class MDCFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain chain) throws IOException, ServletException {
		try {
			initialiazeMdcContext(request);
			chain.doFilter(request, response);
		} finally {
			MDC.clear();
		}
	}

	/*
	 * Initializes MDC context
	 * 
	 * @param httpRequest
	 */
	private void initialiazeMdcContext(HttpServletRequest httpRequest) {
		MDC.put(TailTrackingConstants.TRANSACTION_ID.getValue(), UUID.randomUUID().toString());
		MDC.put(TailTrackingConstants.CARRIER_CODE.getValue(),
				httpRequest.getParameter(TailTrackingConstants.CARRIER_CODE.getValue()));
		MDC.put(TailTrackingConstants.FLIGHT_NUMBER.getValue(),
				httpRequest.getParameter(TailTrackingConstants.FLIGHT_NUMBER.getValue()));
		MDC.put(TailTrackingConstants.SCH_DEP_DATE.getValue(),
				httpRequest.getParameter(TailTrackingConstants.SCH_DEP_DATE.getValue()));
		MDC.put(TailTrackingConstants.ARR_STN.getValue(),
				httpRequest.getParameter(TailTrackingConstants.ARR_STN.getValue()));
		MDC.put(TailTrackingConstants.DEP_STN.getValue(),
				httpRequest.getParameter(TailTrackingConstants.DEP_STN.getValue()));
		MDC.put(TailTrackingConstants.TAIL_NUMBER.getValue(),
				httpRequest.getParameter(TailTrackingConstants.TAIL_NUMBER.getValue()));
	}
}
