package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;


/**
 * The Interface CarrierCodeValidator.
 */
@Documented
@Constraint(validatedBy = CarrierCodeConstraint.class)
@Target( {ElementType.FIELD,ElementType.PARAMETER} )
@Retention(RetentionPolicy.RUNTIME)
public @interface CarrierCodeValidator {
String message() default "BETTFUNC1001";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

}
