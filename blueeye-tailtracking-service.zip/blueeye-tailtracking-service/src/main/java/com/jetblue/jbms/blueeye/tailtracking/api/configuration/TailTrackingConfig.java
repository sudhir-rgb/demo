package com.jetblue.jbms.blueeye.tailtracking.api.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jetblue.jbms.common.configuration.CommonConfig;
import com.jetblue.jbms.common.controller.ReadyController;
import com.jetblue.jbms.common.cors.CorsAndHeaderFilter;

@Configuration
public class TailTrackingConfig extends CommonConfig {

	@Bean
	public ReadyController readyController() {
		return new ReadyController() {
		};
	}

	@Bean
	public CorsAndHeaderFilter corsAndHeaderFilter() {
		return new CorsAndHeaderFilter();
	}
}
