/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.test;

import static org.junit.Assert.assertEquals;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * @author TBhorkar
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class CustomValidatorTest {

	private Validator validator;
	
	@Before
	public void init() {
		validator = Validation.buildDefaultValidatorFactory().getValidator();
	}
	
	@Test
	public void testValidCase() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("JFK");
		request.setFlightNumber("1611");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("982");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(true, constraintViolations.isEmpty());
	}
	
	
	@Test
	public void testInvalidTailNumber() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("JFK");
		request.setFlightNumber("1611");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("invalid");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
	
	@Test
	public void testInvalidTailNumber2() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("JFK");
		request.setFlightNumber("1611");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
	
	@Test
	public void testInvalidDepStn() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("invalid");
		request.setFlightNumber("1611");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("982");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
	
	@Test
	public void testInvalidDepStn2() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("");
		request.setFlightNumber("1611");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("982");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
	
	@Test
	public void testInvalidDate() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("JFK");
		request.setFlightNumber("1611");
		request.setSchDepDate("invalid");
		request.setTailNumber("982");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
	
	@Test
	public void testInvalidFlightNumber() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("invalid");
		request.setFlightNumber("invalid");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("982");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
	
	@Test
	public void testInvalidFlightNumber2() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("JFK");
		request.setFlightNumber("");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("982");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
	
	@Test
	public void testInvalidFlightNumber3() {
		DummyRequest request = new DummyRequest();
		request.setAirlineCode("B6");
		request.setArrStn("LAS");
		request.setDepStn("JFK");
		request.setFlightNumber("15664");
		request.setSchDepDate("2020-05-21");
		request.setTailNumber("982");
		Set<ConstraintViolation<DummyRequest>> constraintViolations = validator.validate(request);
		assertEquals(false, constraintViolations.isEmpty());
	}
}
