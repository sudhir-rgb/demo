/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.filter.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.jetblue.jbms.blueeye.tailtracking.api.filter.MDCFilter;
import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingConstants;

/**
 * @author TBhorkar
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class MDCFilterTest {

	@InjectMocks
	private MDCFilter targetBeingTested;
	
	@Mock
	private HttpServletRequest mockRequest;
	@Mock
	private FilterChain mockFilterChain;
	@Mock
	private HttpServletResponse mockResponse;
	
	
	@Test
	public void testMdcContext() throws ServletException, IOException {
		targetBeingTested.doFilter(mockRequest, mockResponse, mockFilterChain);
		verify(mockRequest, times(1)).getParameter(TailTrackingConstants.CARRIER_CODE.getValue());
		verify(mockRequest, times(1)).getParameter(TailTrackingConstants.FLIGHT_NUMBER.getValue());
		verify(mockRequest, times(1)).getParameter(TailTrackingConstants.TAIL_NUMBER.getValue());
		verify(mockRequest, times(1)).getParameter(TailTrackingConstants.DEP_STN.getValue());
	}
}
