/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.test;

import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.CarrierCodeValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.DateValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.DepStnValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.FlightNumberValidator;
import com.jetblue.jbms.blueeye.tailtracking.api.customvalidator.TailNumberValidator;

/**
 * @author TBhorkar
 * 
 */
public class DummyRequest {

	@CarrierCodeValidator
	private String airlineCode;
	@DateValidator
	private String schDepDate;
	@DepStnValidator
	private String depStn;
	private String arrStn;
	@TailNumberValidator
	private String tailNumber;
	@FlightNumberValidator
	private String flightNumber;
	
	public String getAirlineCode() {
		return airlineCode;
	}
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}
	public String getSchDepDate() {
		return schDepDate;
	}
	public void setSchDepDate(String schDepDate) {
		this.schDepDate = schDepDate;
	}
	public String getDepStn() {
		return depStn;
	}
	public void setDepStn(String depStn) {
		this.depStn = depStn;
	}
	public String getArrStn() {
		return arrStn;
	}
	public void setArrStn(String arrStn) {
		this.arrStn = arrStn;
	}
	public String getTailNumber() {
		return tailNumber;
	}
	public void setTailNumber(String tailNumber) {
		this.tailNumber = tailNumber;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
}
