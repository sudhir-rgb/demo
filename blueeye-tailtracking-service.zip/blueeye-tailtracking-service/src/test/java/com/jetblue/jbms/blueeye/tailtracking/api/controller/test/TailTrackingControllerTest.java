package com.jetblue.jbms.blueeye.tailtracking.api.controller.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.jetblue.jbms.blueeye.tailtracking.api.Application;
import com.jetblue.jbms.blueeye.tailtracking.api.controller.TailTrackingController;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingDetails;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingDetailsResponse;
import com.jetblue.jbms.blueeye.tailtracking.api.service.TailTrackingService;
import com.jetblue.jbms.blueeye.tailtracking.api.util.TailTrackingConstants;

@RunWith(SpringJUnit4ClassRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(classes= {Application.class})
public class TailTrackingControllerTest {

	@InjectMocks
	private TailTrackingController targetBeingTested;

	@Autowired
	private MockMvc mockMvc;

	@Mock
	private TailTrackingService tailTrackingService;

	private static final String BASE_URI = "/blueeye/flight/tailtracking";

	@Before
	public void setup() {

		mockMvc = MockMvcBuilders.standaloneSetup(targetBeingTested).build();
	}

	@Test
	public void testTailTrackingControllerSuccessResponse() throws Exception {
		when(tailTrackingService.getTailTrackingDetails(null, "1523", "2020-04-15", "JFK",null, "984"))
				.thenReturn(getTailTrackingDetails());
		mockMvc.perform(get(BASE_URI)
				.param(TailTrackingConstants.FLIGHT_NUMBER.getValue(), "1523")
				.param(TailTrackingConstants.SCH_DEP_DATE.getValue(), "2020-04-15")
				.param(TailTrackingConstants.DEP_STN.getValue(), "JFK")
				.param(TailTrackingConstants.TAIL_NUMBER.getValue(), "984"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.TailTrackingDetails").exists());
		verify(tailTrackingService, times(1)).getTailTrackingDetails(null, "1523", "2020-04-15", "JFK",null, "984");
		verifyNoMoreInteractions(tailTrackingService);
	}
	
	private TailTrackingDetailsResponse getTailTrackingDetails() {
		TailTrackingDetailsResponse response = new TailTrackingDetailsResponse();
		TailTrackingDetails tailtrackingDetails = new TailTrackingDetails();
		response.setTailTrackingDetails(tailtrackingDetails);
		return response;
	}

}