package com.jetblue.jbms.blueeye.tailtracking.api.service.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jetblue.jbms.blueeye.tailtracking.api.model.TailTrackingDetailsResponse;
import com.jetblue.jbms.blueeye.tailtracking.api.service.FlightDomainService;
import com.jetblue.jbms.blueeye.tailtracking.api.service.ReferenceDomainService;
import com.jetblue.jbms.blueeye.tailtracking.api.service.TailTrackingService;
import com.jetblue.jbms.common.exception.JbException;
import com.jetblue.jbms.common.flight.model.TailTrackingDetail;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosNoDataFoundException;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosTechnicalException;
import com.jetblue.jbms.cosmos.common.ref.model.AcftTailDesignTypeDocument;
import com.jetblue.jbms.cosmos.common.ref.model.Aircraft;

@RunWith(MockitoJUnitRunner.class)
public class TailTrackingServiceTest {

	@InjectMocks
	private TailTrackingService targetBeingTested;

	@Mock
	private FlightDomainService flightDomainService;

	@Mock
	private ReferenceDomainService refDomainService;

	@Test
	public void testTailTrackingServiceTailResponse() throws IOException, Exception {
		ObjectMapper mapper = new ObjectMapper();
		Charset charset = StandardCharsets.UTF_8;

		InputStream inputStream = new ClassPathResource("TailTrackingQuery_Response.json").getInputStream();
		String queryResponse = getQueryResponse(inputStream, charset);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<TailTrackingDetail> listTailTrackingRepo = mapper.readValue(queryResponse,
				new TypeReference<List<TailTrackingDetail>>() {
				});

		when(flightDomainService.getTailTrackingResponse(anyString(), anyString())).thenReturn(listTailTrackingRepo);
		when(refDomainService.getAllAircrafts()).thenReturn(getAcftByTailNumber("982"));
		when(refDomainService.getTailDesignDetails()).thenReturn(getTailDesignDetails());

		TailTrackingDetailsResponse tailTrackingDetailsActualResponse = targetBeingTested.getTailTrackingDetails("B6",
				"1611", "2020-05-21", "JFK", "LAS", "982");

		assertNotNull(tailTrackingDetailsActualResponse);
		assertNull(tailTrackingDetailsActualResponse.getTailTrackingDetails().getFuture().get(0).getAircraftResponse());
		Assert.assertTrue("B6".equalsIgnoreCase(
				tailTrackingDetailsActualResponse.getTailTrackingDetails().getCurrent().get(0).getCarrierCode()));

		verify(flightDomainService, times(1)).getTailTrackingResponse(anyString(), anyString());
		verifyNoMoreInteractions(flightDomainService);
		verify(refDomainService, times(1)).getAllAircrafts();
		verify(refDomainService, times(1)).getTailDesignDetails();
		verifyNoMoreInteractions(refDomainService);

	}
	
	
	@Test
	public void testTailTrackingServiceTailResponse2() throws IOException, Exception {
		ObjectMapper mapper = new ObjectMapper();
		Charset charset = StandardCharsets.UTF_8;

		InputStream inputStream = new ClassPathResource("TailTrackingQuery_Response.json").getInputStream();
		String queryResponse = getQueryResponse(inputStream, charset);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<TailTrackingDetail> listTailTrackingRepo = mapper.readValue(queryResponse,
				new TypeReference<List<TailTrackingDetail>>() {
				});
		listTailTrackingRepo.stream().forEach(repo -> {
			repo.getFlight().getScheduledFlightLeg().getCurrentFlightLeg().setActualFlightType("DVC");
		});
		when(flightDomainService.getTailTrackingResponse(anyString(), anyString())).thenReturn(listTailTrackingRepo);
		when(refDomainService.getAllAircrafts()).thenReturn(getAcftByTailNumber("982"));
		when(refDomainService.getTailDesignDetails()).thenReturn(getTailDesignDetails());

		TailTrackingDetailsResponse tailTrackingDetailsActualResponse = targetBeingTested.getTailTrackingDetails("B6",
				"1611", "2020-05-21", "JFK", "LAS", "982");

		assertNotNull(tailTrackingDetailsActualResponse);
		Assert.assertTrue("B6".equalsIgnoreCase(
				tailTrackingDetailsActualResponse.getTailTrackingDetails().getCurrent().get(0).getCarrierCode()));

		verify(flightDomainService, times(1)).getTailTrackingResponse(anyString(), anyString());
		verifyNoMoreInteractions(flightDomainService);
		verify(refDomainService, times(1)).getAllAircrafts();
		verify(refDomainService, times(1)).getTailDesignDetails();
		verifyNoMoreInteractions(refDomainService);

	}
	
	@Test
	public void testTailTrackingServiceTailResponse3() throws IOException, Exception {
		ObjectMapper mapper = new ObjectMapper();
		Charset charset = StandardCharsets.UTF_8;

		InputStream inputStream = new ClassPathResource("TailTrackingQuery_Response.json").getInputStream();
		String queryResponse = getQueryResponse(inputStream, charset);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<TailTrackingDetail> listTailTrackingRepo = mapper.readValue(queryResponse,
				new TypeReference<List<TailTrackingDetail>>() {
				});
		listTailTrackingRepo.stream().forEach(repo -> {
			repo.getFlight().getScheduledFlightLeg().getCurrentFlightLeg().setStatus("Cancel");
		});
		when(flightDomainService.getTailTrackingResponse(anyString(), anyString())).thenReturn(listTailTrackingRepo);
		when(refDomainService.getAllAircrafts()).thenReturn(getAcftByTailNumber("982"));
		when(refDomainService.getTailDesignDetails()).thenReturn(getTailDesignDetails());

		TailTrackingDetailsResponse tailTrackingDetailsActualResponse = targetBeingTested.getTailTrackingDetails("B6",
				"1611", "2020-05-21", "JFK", "LAS", "982");

		assertNotNull(tailTrackingDetailsActualResponse);
		Assert.assertTrue("B6".equalsIgnoreCase(
				tailTrackingDetailsActualResponse.getTailTrackingDetails().getCurrent().get(0).getCarrierCode()));

		verify(flightDomainService, times(1)).getTailTrackingResponse(anyString(), anyString());
		verifyNoMoreInteractions(flightDomainService);
		verify(refDomainService, times(1)).getAllAircrafts();
		verify(refDomainService, times(1)).getTailDesignDetails();
		verifyNoMoreInteractions(refDomainService);

	}
	
	@Test
	public void testTailTrackingServiceTailResponse4() throws IOException, Exception {
		ObjectMapper mapper = new ObjectMapper();
		Charset charset = StandardCharsets.UTF_8;

		InputStream inputStream = new ClassPathResource("TailTrackingQuery_Response.json").getInputStream();
		String queryResponse = getQueryResponse(inputStream, charset);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<TailTrackingDetail> listTailTrackingRepo = mapper.readValue(queryResponse,
				new TypeReference<List<TailTrackingDetail>>() {
				});
		listTailTrackingRepo.stream().forEach(repo -> {
			repo.getFlight().getScheduledFlightLeg().getCurrentFlightLeg().setCurrentDepStnCode("FLL");
		});
		when(flightDomainService.getTailTrackingResponse(anyString(), anyString())).thenReturn(listTailTrackingRepo);
		when(refDomainService.getAllAircrafts()).thenReturn(getAcftByTailNumber("982"));
		when(refDomainService.getTailDesignDetails()).thenReturn(getTailDesignDetails());

		TailTrackingDetailsResponse tailTrackingDetailsActualResponse = targetBeingTested.getTailTrackingDetails("B6",
				"1611", "2020-05-21", "FLL", "LAS", "982");

		assertNotNull(tailTrackingDetailsActualResponse);
		Assert.assertTrue("B6".equalsIgnoreCase(
				tailTrackingDetailsActualResponse.getTailTrackingDetails().getCurrent().get(0).getCarrierCode()));

		verify(flightDomainService, times(1)).getTailTrackingResponse(anyString(), anyString());
		verifyNoMoreInteractions(flightDomainService);
		verify(refDomainService, times(1)).getAllAircrafts();
		verify(refDomainService, times(1)).getTailDesignDetails();
		verifyNoMoreInteractions(refDomainService);

	}

	@Test(expected = JbException.class)
	public void testExceptionCase() throws JbException {
		when(flightDomainService.getTailTrackingResponse(anyString(), anyString()))
				.thenReturn(new ArrayList<TailTrackingDetail>());
		targetBeingTested.getTailTrackingDetails("B6", "1611", "2020-05-21", "JFK", "LAS", "982");
	}

	@Test(expected = JbException.class)
	public void testExceptionCase2()
			throws IOException, JbException, RefCosmosTechnicalException, RefCosmosNoDataFoundException {
		ObjectMapper mapper = new ObjectMapper();
		Charset charset = StandardCharsets.UTF_8;

		InputStream inputStream = new ClassPathResource("TailTrackingQuery_Response.json").getInputStream();
		String queryResponse = getQueryResponse(inputStream, charset);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<TailTrackingDetail> listTailTrackingRepo = mapper.readValue(queryResponse,
				new TypeReference<List<TailTrackingDetail>>() {
				});
		listTailTrackingRepo.stream().forEach(repo -> {
			repo.getFlight().setFlightNumber(null);
		});
		when(flightDomainService.getTailTrackingResponse(anyString(), anyString())).thenReturn(listTailTrackingRepo);
		targetBeingTested.getTailTrackingDetails("B6", "1611", "2020-05-21", "JFK", "LAS", "982");
	}

	private String getQueryResponse(InputStream inputStream, Charset charset) throws IOException {
		try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, charset))) {
			return br.lines().collect(Collectors.joining(System.lineSeparator()));
		}
	}

	private Map<String,List<AcftTailDesignTypeDocument>> getTailDesignDetails() {
		Map<String, List<AcftTailDesignTypeDocument>> aircraftTailMap = new HashMap<>();
		List<AcftTailDesignTypeDocument> tailDesignList = new ArrayList<>();
		AcftTailDesignTypeDocument tailDesignDoc = new AcftTailDesignTypeDocument();
		tailDesignDoc.setAcftTailDesignTypeCode("Prism");
		tailDesignList.add(tailDesignDoc);
		aircraftTailMap.put("Prism", tailDesignList);
		return aircraftTailMap;
	}

	private Map<String, List<Aircraft>> getAcftByTailNumber(String tailNumber) {
		Map<String, List<Aircraft>> aircraftMap = new HashMap<>();
		List<Aircraft> aircraftList = new ArrayList<>();
		Aircraft aircraft = new Aircraft();
		aircraft.setAcftTailNumber(tailNumber);
		aircraft.setTailfinDesignURL("url");
		aircraft.setAcftTailDesignTypeCode("Prism");
		aircraftList.add(aircraft);
		aircraftMap.put(tailNumber, aircraftList);
		return aircraftMap;
	}

}