/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.service.test;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.jetblue.jbms.blueeye.tailtracking.api.service.FlightDomainService;
import com.jetblue.jbms.common.exception.JbException;
import com.jetblue.jbms.common.flight.model.TailTrackingDetail;
import com.jetblue.jbms.common.flight.service.FlightInformationService;

/**
 * @author TBhorkar
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class FlightDomainServiceTest {

	@InjectMocks
	private FlightDomainService targetBeingTested;

	@Mock
	private FlightInformationService flightInfoService;

	@Test
	public void testTailTrackingInfo() throws JbException {
		when(flightInfoService.getTailTrackingResponse(anyString(), anyString()))
				.thenReturn(new ArrayList<TailTrackingDetail>());
		assertNotNull(targetBeingTested.getTailTrackingResponse(anyString(), anyString()));
		verify(flightInfoService, times(1)).getTailTrackingResponse(anyString(), anyString());
		verifyNoMoreInteractions(flightInfoService);
	}

}
