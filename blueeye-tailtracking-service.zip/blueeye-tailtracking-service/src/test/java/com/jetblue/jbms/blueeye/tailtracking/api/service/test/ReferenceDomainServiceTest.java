/**
 * 
 */
package com.jetblue.jbms.blueeye.tailtracking.api.service.test;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.jetblue.jbms.blueeye.tailtracking.api.service.ReferenceDomainService;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosNoDataFoundException;
import com.jetblue.jbms.cosmos.common.ref.exp.RefCosmosTechnicalException;
import com.jetblue.jbms.cosmos.common.ref.model.AcftTailDesignTypeDocument;
import com.jetblue.jbms.cosmos.common.ref.service.impl.RefCosmosCommonServiceImpl;

/**
 * @author TBhorkar
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class ReferenceDomainServiceTest {

	@InjectMocks
	private ReferenceDomainService targetBeingTested;
	@Mock
	private RefCosmosCommonServiceImpl refCosmosService;
	
	
	@Test
	public void getAircraftByTailNumberTest() throws RefCosmosTechnicalException, RefCosmosNoDataFoundException {
		when(refCosmosService.getAllAircraft()).thenReturn(new ArrayList<>());
		assertNotNull(targetBeingTested.getAllAircrafts());
		verify(refCosmosService, times(1)).getAllAircraft();
		verifyNoMoreInteractions(refCosmosService);
	}
	
	@Test
	public void getTailDesignDetailsTest() throws RefCosmosTechnicalException {
		List<AcftTailDesignTypeDocument> tailDesignDetailsList = new ArrayList<>();
		when(refCosmosService.getAcftTailDesignTypeQuery()).thenReturn(tailDesignDetailsList);
		assertNotNull(targetBeingTested.getTailDesignDetails());
		verify(refCosmosService, times(1)).getAcftTailDesignTypeQuery();
		verifyNoMoreInteractions(refCosmosService);
	}
	
	
}
