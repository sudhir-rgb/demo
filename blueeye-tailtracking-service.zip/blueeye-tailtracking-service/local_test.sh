export B6_BUILD_ID=123
export JBbook_config_file=./empty.properties
java -jar build/libs/citypair-search-service-$B6_BUILD_ID.jar --app.build.number=1234  --spring.config.location=./src/test/resources/tail-tracking-application.properties

